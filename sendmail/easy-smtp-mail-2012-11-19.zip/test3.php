<?php

/* set zona waktu */
date_default_timezone_set('Asia/Jakarta');

include_once("smtp.mail.class.php");

$email = new SMTPMail("A Domain","smtp.gmail.com","a.mail@a-domain.com","mypassword","tls",587);

$message = "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ligula felis, cursus vel tincidunt ac, vestibulum at ante. Nam metus ligula, luctus a tincidunt nec, fermentum ut ligula. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In massa arcu, pulvinar sit amet tempus adipiscing, ultrices in nisl. Etiam ac est et mauris fringilla vestibulum. Suspendisse a elit eros, eu gravida lorem. Donec mi nibh, venenatis nec accumsan quis, vestibulum ut sapien. In scelerisque nibh rutrum mi porta in semper diam dictum. Donec non erat risus. Nunc purus nisl, scelerisque eu posuere nec, gravida in erat. Donec orci sapien, iaculis sit amet convallis at, rutrum at ipsum. In hac habitasse platea dictumst. Ut dolor dolor, convallis nec fringilla sed, semper ac nisl. Aenean sollicitudin aliquam lectus, non commodo augue convallis vitae. Cras vitae neque lacus. Vestibulum non quam felis.</p>";

$message .= "<p style=\"color:#f00\">Vestibulum porta venenatis felis, non volutpat lorem ullamcorper vel. In sit amet nulla id felis pellentesque imperdiet. Duis ut accumsan risus. Nulla tortor odio, consequat in pulvinar eu, feugiat ac felis. Vivamus lacinia lacinia velit vel tincidunt. Integer tempor dolor nec nulla varius porttitor. Nullam vitae dui orci, tincidunt malesuada purus. In hac habitasse platea dictumst. In non justo tellus. Morbi volutpat malesuada tortor.</p>";

$message .= "<p style=\"font-style:italic\">Etiam sem nulla, elementum rutrum tincidunt sit amet, ultrices ac sem. Phasellus consectetur dui ipsum, a pellentesque augue. Nulla felis mi, rhoncus eget dignissim ac, vestibulum quis dolor. Integer quis lacus enim, ut pretium massa. Curabitur vel arcu id diam adipiscing porta. Ut quam erat, sagittis id faucibus eget, hendrerit a erat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent euismod cursus diam eget lacinia. Phasellus congue ullamcorper tortor. Maecenas tristique, lacus in suscipit tincidunt, odio mauris pulvinar diam, vitae viverra eros tellus in lorem. Nulla vitae sapien ligula. Ut ut orci vel elit consequat scelerisque a vitae leo. Mauris tincidunt condimentum lacus blandit pretium. Nullam et arcu sed urna interdum interdum et eu lacus. Fusce eu orci quis odio sagittis lacinia sit amet non ante.</p>";

$message .= "<p style=\"font-size:large\">In vulputate vehicula mi ut interdum. Nullam turpis nisl, pulvinar sit amet malesuada in, ullamcorper et nisl. Morbi consectetur mauris risus, eget molestie enim. Donec ut arcu mauris. Duis posuere ante odio. Nullam elit risus, fringilla nec hendrerit eget, ornare vitae mi. Cras iaculis dictum elit vel tristique. Aenean tristique sollicitudin vestibulum. Maecenas lacinia orci eget tortor tincidunt congue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Praesent a sapien nec ligula pulvinar dignissim. Curabitur eu diam nunc, et porttitor neque. Etiam facilisis, ante quis laoreet ullamcorper, nunc magna pretium est, eu tristique erat justo quis velit. Integer ac urna vitae odio lacinia ultrices. Nam orci urna, suscipit accumsan porta vel, vulputate quis magna. Maecenas vel dui in nulla egestas aliquet a sit amet orci.</p>";

$message .= "<p style=\"font-weight:bold\">Nam luctus cursus nibh, ut mattis enim auctor id. Mauris sit amet enim et est sagittis fermentum. Donec pretium ultricies nisl sit amet facilisis. Praesent eget risus sit amet eros iaculis viverra. Praesent tristique erat at lectus dignissim a mattis lacus elementum. Proin molestie metus vel ligula posuere molestie. Sed molestie, lacus quis pretium tristique, ipsum neque volutpat ligula, sit amet vestibulum libero turpis molestie tortor. Nunc accumsan ligula sed ante mattis volutpat varius dui porttitor. </p>";

$to[0] = "Another User Name <another.mail@another-domain.com>";
$to[1] = "Another User Name 2 <another.mail2@another-domain.com>";
$cc = "Another User Name 3 <another.mail3@another-domain.com>";
$from = "User Name <a.mail@a-domain.com>";
$bcc = "Another User Name 4 <another.mail4@another-domain.com>";
$subject = "New Test Email ".date("r");
$attachment = array(
				"docs/rfc821.pdf",
				"docs/rfc1893.pdf"
			  );

$send = $email->Send($subject,$message,$to,$from,'',$cc,$bcc,$attachment);

if($send===false) {
	echo "Email is not sent<br /><br />";

	sort($email->debugReport());

	foreach($email->debugReport() as $report) {
		$report = explode("|",$report);
		echo "<b>".$report[0]." <span style='color: #f00'>".$report[1]."</span></b><br />";
	}
} else {
	echo "Email has been sent";
}

?>